export const sitekey = "testing";
export const authors_path = (letter) => `/${sitekey}/authors${ letter ? `?letter=${letter}` :""}`;
export const ws_protocol = 'wss://';
